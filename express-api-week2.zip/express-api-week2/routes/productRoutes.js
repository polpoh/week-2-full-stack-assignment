const express = require("express");
const router = express.Router();
const {
  getProducts,
  getProduct,
  createProduct,
  updateProduct,
  deleteProduct,
  searchProducts,
  getStats
} = require("../controllers/productController");

const validateProduct = require("../middleware/validateProduct");

// search + stats (place before :id routes to avoid conflict)
router.get("/search/name", searchProducts);
router.get("/stats/category", getStats);

// CRUD routes
router.get("/", getProducts);
router.get("/:id", getProduct);
router.post("/", validateProduct, createProduct);
router.put("/:id", validateProduct, updateProduct);
router.delete("/:id", deleteProduct);

module.exports = router;
