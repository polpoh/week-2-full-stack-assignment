module.exports = [
  {
    id: "1",
    name: "Laptop",
    description: "High-performance laptop",
    price: 1200,
    category: "electronics",
    inStock: true
  },
  {
    id: "2",
    name: "Phone",
    description: "Smartphone with good camera",
    price: 700,
    category: "electronics",
    inStock: true
  },
  {
    id: "3",
    name: "Office Chair",
    description: "Ergonomic chair",
    price: 150,
    category: "furniture",
    inStock: false
  }
];
