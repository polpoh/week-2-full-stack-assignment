const { v4: uuidv4 } = require("uuid");
const NotFoundError = require("../errors/NotFoundError");
let products = require("../data/products");

exports.getProducts = (req, res) => {
  let { category, page = 1, limit = 5 } = req.query;

  let items = products.slice(); // copy

  // filtering
  if (category) {
    items = items.filter(p => p.category === category);
  }

  // pagination
  page = Number(page);
  limit = Number(limit);
  const start = (page - 1) * limit;
  const end = start + limit;
  const paged = items.slice(start, end);

  res.json({ success: true, total: items.length, page, data: paged });
};

exports.getProduct = (req, res, next) => {
  try {
    const product = products.find(p => p.id === req.params.id);

    if (!product) {
      throw new NotFoundError("Product not found");
    }

    res.json(product);
  } catch (err) {
    next(err);
  }
};

exports.createProduct = (req, res, next) => {
  try {
    const newProduct = { id: uuidv4(), ...req.body };
    products.push(newProduct);
    res.status(201).json(newProduct);
  } catch (err) {
    next(err);
  }
};

exports.updateProduct = (req, res, next) => {
  try {
    const index = products.findIndex(p => p.id === req.params.id);

    if (index === -1) {
      throw new NotFoundError("Product not found");
    }

    products[index] = { ...products[index], ...req.body };

    res.json(products[index]);
  } catch (err) {
    next(err);
  }
};

exports.deleteProduct = (req, res, next) => {
  try {
    const index = products.findIndex(p => p.id === req.params.id);

    if (index === -1) {
      throw new NotFoundError("Product not found");
    }

    products.splice(index, 1);
    res.json({ message: "Product deleted" });
  } catch (err) {
    next(err);
  }
};

exports.searchProducts = (req, res) => {
  const q = (req.query.q || "").toLowerCase();

  const results = products.filter(p =>
    p.name.toLowerCase().includes(q)
  );

  res.json({ success: true, count: results.length, results });
};

exports.getStats = (req, res) => {
  const stats = {};

  products.forEach(p => {
    stats[p.category] = (stats[p.category] || 0) + 1;
  });

  res.json({ success: true, stats });
};
