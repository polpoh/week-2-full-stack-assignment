# Express API — Week 2 Assignment

## Overview
A simple Express.js RESTful API for managing `products`. Implements CRUD routes, middleware (logger, auth, validation), error handling, filtering, pagination, search, and basic statistics.

## Quick start
1. Install dependencies:
   ```bash
   npm install
   ```
2. Create a `.env` file using `.env.example` and set `API_KEY`.
3. Start the server:
   ```bash
   npm start
   ```
   or, during development:
   ```bash
   npm run dev
   ```
4. Server runs on http://localhost:3000 by default.

## API Endpoints
- `GET /` — Hello World
- `GET /api/products` — List products (supports `?category=...`, `?page=...`, `?limit=...`)
- `GET /api/products/:id` — Get a product by id
- `POST /api/products` — Create product (requires JSON body)
- `PUT /api/products/:id` — Update product
- `DELETE /api/products/:id` — Delete product
- `GET /api/products/search/name?q=term` — Search products by name
- `GET /api/products/stats/category` — Product count by category

## Sample product JSON
```json
{
  "name": "Laptop",
  "description": "High-performance laptop",
  "price": 1200,
  "category": "electronics",
  "inStock": true
}
```

## Notes for the assignment submission
- Include all files in the repository.
- Add `.env.example` (do NOT commit `.env` with real API keys).
- Ensure README documents how to run and example requests.
- The autograder will run `npm install` and `npm start` — keep `PORT` configurable via env.

## Author
Generated for assignment submission.
