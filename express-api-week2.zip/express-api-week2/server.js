const express = require("express");
const logger = require("./middleware/logger");
const auth = require("./middleware/auth");
const errorHandler = require("./middleware/errorHandler");
const dotenv = require("dotenv");
dotenv.config();

const app = express();
const productRoutes = require("./routes/productRoutes");

// parse JSON
app.use(express.json());

// custom logger middleware
app.use(logger);

// authentication middleware (applies to all /api routes)
app.use("/api", auth);

// routes
app.use("/api/products", productRoutes);

// hello world
app.get("/", (req, res) => {
  res.send("Hello World from Express!");
});

// global error handler
app.use(errorHandler);

// start server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log("Server running on port " + PORT));
